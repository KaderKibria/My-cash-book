package com.mycashbook

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Calendar

class HomeViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDb.get(app).dao()
    private val from: Long
    private val to: Long
    init {
        val c = Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
        from = c.timeInMillis
        c.add(Calendar.MONTH, 1); to = c.timeInMillis - 1
        viewModelScope.launch { seed() }
    }
    val balances = dao.balances().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val income = dao.monthTotal("INCOME", from, to).stateIn(viewModelScope, SharingStarted.Eagerly, 0L)
    val expense = dao.monthTotal("EXPENSE", from, to).stateIn(viewModelScope, SharingStarted.Eagerly, 0L)
    val recent = dao.recent(3).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val accounts = dao.accounts().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val all = dao.allTxns().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    fun categories(type: String) = dao.categories(type)
    fun add(type: String, accountId: Long, toId: Long?, catId: Long?, amountMinor: Long, note: String) =
        viewModelScope.launch { dao.addTxn(Txn(type = type, accountId = accountId, toAccountId = toId, categoryId = catId, amountMinor = amountMinor, note = note, date = System.currentTimeMillis())) }
    fun delete(id: Long) = viewModelScope.launch { dao.deleteById(id) }

    private suspend fun seed() {
        if (dao.accountCount() > 0) return
        dao.addAccount(Account(name = "Cash", type = "CASH"))
        dao.addAccount(Account(name = "Bank", type = "BANK"))
        dao.addAccount(Account(name = "Mobile Banking", type = "MOBILE"))
        listOf("Salary" to "বেতন", "Business" to "ব্যবসা").forEach { dao.addCategory(Category(nameEn = it.first, nameBn = it.second, type = "INCOME")) }
        listOf("Food" to "খাবার", "Transport" to "যাতায়াত", "Beauty / Salon" to "বিউটি / সেলুন", "Bills" to "বিল", "Health" to "স্বাস্থ্য", "Shopping" to "কেনাকাটা")
            .forEach { dao.addCategory(Category(nameEn = it.first, nameBn = it.second, type = "EXPENSE")) }
    }
}
