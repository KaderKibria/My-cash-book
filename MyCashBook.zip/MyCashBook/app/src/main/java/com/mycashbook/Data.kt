package com.mycashbook

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

// All money is stored as Long minor units (poisha) to avoid floating-point errors.
@Entity(tableName = "accounts")
data class Account(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String, val type: String, val openingMinor: Long = 0) // CASH | BANK | MOBILE

@Entity(tableName = "categories")
data class Category(@PrimaryKey(autoGenerate = true) val id: Long = 0, val nameEn: String, val nameBn: String, val type: String)

@Entity(tableName = "txns", indices = [Index("date"), Index("accountId")])
data class Txn(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String, // INCOME | EXPENSE | TRANSFER
    val accountId: Long, val toAccountId: Long? = null, val categoryId: Long? = null,
    val amountMinor: Long, val note: String = "", val date: Long)

@Entity(tableName = "budgets")
data class Budget(@PrimaryKey(autoGenerate = true) val id: Long = 0, val categoryId: Long, val monthlyLimitMinor: Long)

@Entity(tableName = "recurring")
data class Recurring(@PrimaryKey(autoGenerate = true) val id: Long = 0, val accountId: Long, val categoryId: Long, val amountMinor: Long, val dayOfMonth: Int, val note: String = "", val lastRunYm: Int = 0)

data class AccountBalance(val id: Long, val name: String, val type: String, val balance: Long)
data class TxnRow(val id: Long, val type: String, val amountMinor: Long, val note: String, val date: Long, val nameEn: String?, val nameBn: String?)

@Dao
interface CashDao {
    @Insert suspend fun addAccount(a: Account): Long
    @Insert suspend fun addCategory(c: Category): Long
    @Insert suspend fun addTxn(t: Txn): Long
    @Update suspend fun updateTxn(t: Txn)
    @Delete suspend fun deleteTxn(t: Txn)
    @Query("SELECT COUNT(*) FROM accounts") suspend fun accountCount(): Int
    @Query("SELECT * FROM accounts ORDER BY id") fun accounts(): Flow<List<Account>>
    @Query("SELECT * FROM categories WHERE type=:type ORDER BY id") fun categories(type: String): Flow<List<Category>>
    @Query("DELETE FROM txns WHERE id=:id") suspend fun deleteById(id: Long)
    @Query("""SELECT t.id, t.type, t.amountMinor, t.note, t.date, c.nameEn, c.nameBn
        FROM txns t LEFT JOIN categories c ON c.id=t.categoryId ORDER BY t.date DESC""")
    fun allTxns(): Flow<List<TxnRow>>

    @Query("""SELECT a.id, a.name, a.type, a.openingMinor + COALESCE((SELECT SUM(CASE
        WHEN t.type='INCOME' AND t.accountId=a.id THEN t.amountMinor
        WHEN t.type='EXPENSE' AND t.accountId=a.id THEN -t.amountMinor
        WHEN t.type='TRANSFER' AND t.accountId=a.id THEN -t.amountMinor
        WHEN t.type='TRANSFER' AND t.toAccountId=a.id THEN t.amountMinor ELSE 0 END)
        FROM txns t WHERE t.accountId=a.id OR t.toAccountId=a.id), 0) AS balance FROM accounts a""")
    fun balances(): Flow<List<AccountBalance>>

    @Query("SELECT COALESCE(SUM(amountMinor),0) FROM txns WHERE type=:type AND date BETWEEN :from AND :to")
    fun monthTotal(type: String, from: Long, to: Long): Flow<Long>

    @Query("""SELECT t.id, t.type, t.amountMinor, t.note, t.date, c.nameEn, c.nameBn
        FROM txns t LEFT JOIN categories c ON c.id=t.categoryId ORDER BY t.date DESC LIMIT :n""")
    fun recent(n: Int): Flow<List<TxnRow>>
}

@Database(entities = [Account::class, Category::class, Txn::class, Budget::class, Recurring::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): CashDao
    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(c: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(c.applicationContext, AppDb::class.java, "cashbook.db").build().also { inst = it }
        }
    }
}
