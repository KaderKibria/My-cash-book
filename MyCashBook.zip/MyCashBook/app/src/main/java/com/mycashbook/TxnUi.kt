package com.mycashbook

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToLong

private fun parseAmount(s: String): Long {
    val ascii = s.map { if (it in '০'..'৯') '0' + (it - '০') else it }.joinToString("")
    return ((ascii.toDoubleOrNull() ?: 0.0) * 100).roundToLong()
}

@Composable
private fun <T> ChipRow(items: List<T>, selected: Long?, id: (T) -> Long, label: (T) -> String, onPick: (Long) -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(items) { FilterChip(selected = id(it) == selected, onClick = { onPick(id(it)) }, label = { Text(label(it)) }) }
    }
}

@Composable
fun AddTxnDialog(type: String, vm: HomeViewModel, onDismiss: () -> Unit) {
    val accounts by vm.accounts.collectAsStateWithLifecycle()
    val catFlow = remember(type) { vm.categories(type) }
    val cats by catFlow.collectAsStateWithLifecycle(emptyList())
    val isBn = Locale.getDefault().language == "bn"
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var accId by remember { mutableStateOf<Long?>(null) }
    var toId by remember { mutableStateOf<Long?>(null) }
    var catId by remember { mutableStateOf<Long?>(null) }
    val from = accId ?: accounts.firstOrNull()?.id
    val to = toId ?: accounts.getOrNull(1)?.id
    val cat = catId ?: cats.firstOrNull()?.id
    val minor = parseAmount(amount)
    val transfer = type == "TRANSFER"
    val ok = minor > 0 && from != null && (!transfer || (to != null && to != from))
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(when (type) { "INCOME" -> R.string.add_income; "EXPENSE" -> R.string.add_expense; else -> R.string.transfer })) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(amount, { amount = it }, label = { Text(stringResource(R.string.amount)) }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                Text(stringResource(if (transfer) R.string.from_account else R.string.accounts), fontSize = 12.sp, color = Color.Gray)
                ChipRow(accounts, from, { it.id }, { it.name }) { accId = it }
                if (transfer) {
                    Text(stringResource(R.string.to_account), fontSize = 12.sp, color = Color.Gray)
                    ChipRow(accounts, to, { it.id }, { it.name }) { toId = it }
                } else {
                    Text(stringResource(R.string.category), fontSize = 12.sp, color = Color.Gray)
                    ChipRow(cats, cat, { it.id }, { if (isBn) it.nameBn else it.nameEn }) { catId = it }
                }
                OutlinedTextField(note, { note = it }, label = { Text(stringResource(R.string.note)) }, singleLine = true)
            }
        },
        confirmButton = {
            TextButton(enabled = ok, onClick = {
                vm.add(type, from!!, if (transfer) to else null, if (transfer) null else cat, minor, note.trim()); onDismiss()
            }) { Text(stringResource(R.string.save)) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) } }
    )
}

@Composable
fun AccountsDialog(vm: HomeViewModel, onDismiss: () -> Unit) {
    val list by vm.balances.collectAsStateWithLifecycle()
    AlertDialog(onDismissRequest = onDismiss, title = { Text(stringResource(R.string.accounts)) },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            list.forEach { Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) { Text(it.name); Text(money(it.balance), fontWeight = FontWeight.SemiBold) } }
        } },
        confirmButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.close)) } })
}

@Composable
fun TransactionsScreen(vm: HomeViewModel) {
    val all by vm.all.collectAsStateWithLifecycle()
    var del by remember { mutableStateOf<Long?>(null) }
    val isBn = Locale.getDefault().language == "bn"
    val fmt = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
    if (all.isEmpty()) { Box(Modifier.fillMaxSize(), Alignment.Center) { Text(stringResource(R.string.no_txns), color = Color.Gray) }; return }
    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(vertical = 12.dp)) {
        items(all, key = { it.id }) { t ->
            val color = when (t.type) { "INCOME" -> Color(0xFF1F8F3F); "EXPENSE" -> Color(0xFFD8262F); else -> Color(0xFF1565C0) }
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(Color.White), elevation = CardDefaults.cardElevation(3.dp)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(if (t.type == "TRANSFER") stringResource(R.string.transfer) else ((if (isBn) t.nameBn else t.nameEn) ?: ""), fontWeight = FontWeight.SemiBold)
                        Text(fmt.format(Date(t.date)), fontSize = 12.sp, color = Color.Gray)
                        if (t.note.isNotBlank()) Text(t.note, fontSize = 12.sp, color = Color.Gray, maxLines = 1)
                    }
                    Text(money(t.amountMinor), color = color, fontWeight = FontWeight.Bold)
                    TextButton(onClick = { del = t.id }) { Text("✕", color = Color.Gray) }
                }
            }
        }
    }
    del?.let { id ->
        AlertDialog(onDismissRequest = { del = null }, title = { Text(stringResource(R.string.delete_q)) },
            confirmButton = { TextButton(onClick = { vm.delete(id); del = null }) { Text(stringResource(R.string.delete)) } },
            dismissButton = { TextButton(onClick = { del = null }) { Text(stringResource(R.string.cancel)) } })
    }
}
