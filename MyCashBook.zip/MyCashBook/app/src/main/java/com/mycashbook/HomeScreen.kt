package com.mycashbook

import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.os.LocaleListCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Navy = Color(0xFF003174); private val Navy2 = Color(0xFF0A3F8F)
private val GreenBg = Color(0xFFD4F3DC); private val GreenFg = Color(0xFF1F8F3F)
private val RedBg = Color(0xFFFDD0D8); private val RedFg = Color(0xFFD8262F)

fun money(minor: Long): String =
    "৳ " + NumberFormat.getNumberInstance(Locale.getDefault()).apply { maximumFractionDigits = 0 }.format(minor / 100)

@Composable
fun CashBookApp() {
    val vm: HomeViewModel = viewModel()
    var dialog by remember { mutableStateOf<String?>(null) }
    var tab by remember { mutableIntStateOf(0) }
    val items = listOf("⌂" to R.string.home, "⇅" to R.string.transactions, "▥" to R.string.reports, "◔" to R.string.budgets, "⚙" to R.string.settings)
    Scaffold(
        containerColor = Color.White,
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                items.forEachIndexed { i, (icon, label) ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i },
                        icon = { Text(icon, fontSize = 20.sp) }, label = { Text(stringResource(label), fontSize = 11.sp, maxLines = 1) })
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            when (tab) {
                0 -> HomeScreen(vm) { dialog = it }
                1 -> TransactionsScreen(vm)
                else -> Box(Modifier.fillMaxSize(), Alignment.Center) { Text(stringResource(R.string.coming_soon)) }
            }
            dialog?.let { d -> if (d == "ACCOUNTS") AccountsDialog(vm) { dialog = null } else AddTxnDialog(d, vm) { dialog = null } }
        }
    }
}

@Composable
fun HomeScreen(vm: HomeViewModel, onAction: (String) -> Unit) {
    val balances by vm.balances.collectAsStateWithLifecycle()
    val income by vm.income.collectAsStateWithLifecycle()
    val expense by vm.expense.collectAsStateWithLifecycle()
    val recent by vm.recent.collectAsStateWithLifecycle()
    var hidden by remember { mutableStateOf(false) }
    fun bal(type: String) = balances.filter { it.type == type }.sumOf { it.balance }
    fun show(v: Long) = if (hidden) "৳ ••••" else money(v)
    val isBn = Locale.getDefault().language == "bn"

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.app_name), fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Navy)
                Row {
                    listOf("EN" to "en", "বাংলা" to "bn").forEach { (label, tag) ->
                        val on = (tag == "bn") == isBn
                        TextButton(onClick = { AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(tag)) }) {
                            Text(label, fontWeight = if (on) FontWeight.Bold else FontWeight.Normal, color = if (on) Navy else Color.Gray)
                        }
                    }
                }
            }
        }
        item {
            Column(Modifier.fillMaxWidth().shadow(12.dp, RoundedCornerShape(26.dp)).clip(RoundedCornerShape(26.dp))
                .background(Brush.linearGradient(listOf(Navy, Navy2))).padding(20.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(stringResource(R.string.total_balance), color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text(" 👁", Modifier.clickable { hidden = !hidden })
                    }
                    Text(show(balances.sumOf { it.balance }), color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.SemiBold)
                }
                Spacer(Modifier.height(18.dp))
                Row(Modifier.fillMaxWidth()) {
                    listOf(Triple("👛", R.string.cash, "CASH"), Triple("🏦", R.string.bank, "BANK"), Triple("📱", R.string.mobile, "MOBILE")).forEach { (ic, label, type) ->
                        Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                            Text(ic, fontSize = 18.sp); Spacer(Modifier.width(6.dp))
                            Column { Text(stringResource(label), color = Color.White.copy(.85f), fontSize = 11.sp, maxLines = 1); Text(show(bal(type)), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
                        }
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                SummaryCard(Modifier.weight(1f), GreenBg, GreenFg, "+", R.string.income, income)
                SummaryCard(Modifier.weight(1f), RedBg, RedFg, "−", R.string.expense, expense)
            }
        }
        item {
            Text(stringResource(R.string.quick_actions), color = Color.Gray, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf(Triple("＋", R.string.add_income, "INCOME"), Triple("－", R.string.add_expense, "EXPENSE"), Triple("⇄", R.string.transfer, "TRANSFER"), Triple("🏦", R.string.accounts, "ACCOUNTS")).forEach { (ic, label, key) ->
                    Card(Modifier.weight(1f).height(92.dp), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(Color.White), elevation = CardDefaults.cardElevation(3.dp), onClick = { onAction(key) }) {
                        Column(Modifier.fillMaxSize().padding(4.dp), Arrangement.Center, Alignment.CenterHorizontally) {
                            Text(ic, fontSize = 22.sp); Spacer(Modifier.height(6.dp))
                            Text(stringResource(label), fontSize = 11.sp, lineHeight = 13.sp, maxLines = 2)
                        }
                    }
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(stringResource(R.string.recent), fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text(stringResource(R.string.see_more), color = Navy, fontWeight = FontWeight.SemiBold)
            }
        }
        items(recent, key = { it.id }) { t ->
            val inc = t.type == "INCOME"
            val fmt = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(Color.White), elevation = CardDefaults.cardElevation(3.dp)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(44.dp).clip(CircleShape).background(if (inc) GreenBg else RedBg), Alignment.Center) { Text(if (inc) "↑" else "↓", color = if (inc) GreenFg else RedFg, fontWeight = FontWeight.Bold) }
                    Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                        Text((if (isBn) t.nameBn else t.nameEn) ?: t.type, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        Text(fmt.format(Date(t.date)), color = Color.Gray, fontSize = 12.sp)
                        if (t.note.isNotBlank()) Text(t.note, color = Color.Gray, fontSize = 12.sp, maxLines = 1)
                    }
                    Text(show(t.amountMinor), color = if (inc) GreenFg else RedFg, fontWeight = FontWeight.Bold)
                }
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

@Composable
private fun SummaryCard(mod: Modifier, bg: Color, fg: Color, sign: String, label: Int, v: Long) {
    Row(mod.clip(RoundedCornerShape(20.dp)).background(bg).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(34.dp).clip(CircleShape).background(fg), Alignment.Center) { Text(sign, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        Column(Modifier.padding(start = 10.dp)) {
            Text(stringResource(R.string.this_month), fontSize = 12.sp)
            Text(money(v), color = fg, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Text(stringResource(label), fontSize = 12.sp)
        }
    }
}
